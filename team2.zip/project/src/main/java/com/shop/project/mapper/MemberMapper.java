package com.shop.project.mapper;

import com.shop.project.dto.Member;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MemberMapper {
	List<Member> selectMember(Member member);

	void insertMember(@Param("member") Member member);
}
