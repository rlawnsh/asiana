package com.shop.project.service;

import com.shop.project.dto.Member;

import java.util.List;

public interface MemberService {

    List<Member> getMember(Member member);

    void postMember(Member member);

}
