package com.example.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Alias("MemberDTO")
public class MemberDTO {
	
	String userid;
	String passwd;
	String username;
	String email1;
	String email2;
	String post;
	String addr1;
	String addr2;
}
