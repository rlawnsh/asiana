package com.example.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Alias("BoardDTO")
public class BoardDTO {
	
	int num;
	String title;
	String author;
	String content;
	String writeday;
	int readcnt;
}
