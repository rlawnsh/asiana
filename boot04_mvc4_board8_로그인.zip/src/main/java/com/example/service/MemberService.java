package com.example.service;

import java.util.List;
import java.util.Map;

import com.example.dto.BoardDTO;
import com.example.dto.MemberDTO;

public interface MemberService {

	public int memberAdd(MemberDTO dto) throws Exception;
	public MemberDTO login(Map<String, String> map) throws Exception;
	
}
