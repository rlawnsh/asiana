package com.example.service;

import java.util.List;

import com.example.dto.BoardDTO;

public interface BoardService {

	public List<BoardDTO> boardList() throws Exception;
	public int boardWrite(BoardDTO dto) throws Exception;
	public BoardDTO boardByNum(int num) throws Exception;
	public int boardUpdate(BoardDTO dto) throws Exception;
	public int boardDelete(int num) throws Exception;
	public int boardMultiDelete(List<Integer> list) throws Exception;
}
