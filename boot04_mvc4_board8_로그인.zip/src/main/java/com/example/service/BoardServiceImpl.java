package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.dto.BoardDTO;
import com.example.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	BoardMapper mapper;

	@Override
	public List<BoardDTO> boardList() throws Exception {
		// TODO Auto-generated method stub
		return mapper.boardList();
	}

	@Transactional
	@Override
	public int boardWrite(BoardDTO dto) throws Exception {
		// TODO Auto-generated method stub
		return mapper.boardWrite(dto);
	}

	@Override
	public BoardDTO boardByNum(int num) throws Exception {
		// TODO Auto-generated method stub
		return mapper.boardByNum(num);
	}

	@Transactional
	@Override
	public int boardUpdate(BoardDTO dto) throws Exception {
		// TODO Auto-generated method stub
		return mapper.boardUpdate(dto);
	}

	@Transactional
	@Override
	public int boardDelete(int num) throws Exception {
		// TODO Auto-generated method stub
		return mapper.boardDelete(num);
	}

	@Transactional
	@Override
	public int boardMultiDelete(List<Integer> list) throws Exception {
		// TODO Auto-generated method stub
		return mapper.boardMultiDelete(list);
	}

}
