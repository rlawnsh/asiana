package com.example.controller;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.dto.BoardDTO;
import com.example.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	BoardService service;

	@GetMapping("/list") // 매핑값인 list로 view인 list.html을 유추한다 
	public @ModelAttribute("boardList") List<BoardDTO> list() throws Exception{
		
		List<BoardDTO> list = service.boardList(); // Model
		return list; // Model
	}
	
	@GetMapping("/writeForm") 
	public String writeForm() throws Exception{
		
		return "write"; // write.html
	}
	
	@GetMapping("/write") 
	public String write(BoardDTO dto) throws Exception{
		int n = service.boardWrite(dto);
		
		return "redirect:list"; // list.html
	}
	
	@GetMapping("/retrieve") 
	public ModelAndView retrieve(@RequestParam(required = false, defaultValue = "0") int num) throws Exception{
		
		ModelAndView mav = new ModelAndView();
		// 모델 저장
		BoardDTO dto = service.boardByNum(num);
		mav.addObject("retrieve", dto);
		
		// 뷰 저장
		mav.setViewName("retrieve");
		return mav; 
	}
	
	@PostMapping("/update") 
	public String update(BoardDTO dto) throws Exception{
		int n = service.boardUpdate(dto);
		return "redirect:list"; // list.html
	}
	
	@GetMapping("/delete") 
	public String delete(@RequestParam(required = false, defaultValue = "1") int num) throws Exception{

		int n = service.boardDelete(num);
		return "redirect:list"; // list.html
	}
	
	@GetMapping("/boardMultiDelete") 
	public String boardMultiDelete(HttpServletRequest request) throws Exception{
		
		String[] checks = request.getParameterValues("check");
		Integer[] checkInt = Stream.of(checks).mapToInt(Integer::parseInt).boxed().toArray(Integer[]::new);
		List<Integer> list = Arrays.asList(checkInt);
		int n = service.boardMultiDelete(list);
		return "forward:list"; 
	}
	
	// 예외처리
	@ExceptionHandler({Exception.class})
	public String error() {
		return "error"; // error.html에서 예외메시지 출력
	}

}
