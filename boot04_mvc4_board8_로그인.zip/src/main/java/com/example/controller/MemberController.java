package com.example.controller;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.dto.MemberDTO;
import com.example.service.MemberService;

@Controller
public class MemberController {
	
	@Autowired
	MemberService service;

	@GetMapping("/signUp")
	public String signUpForm() {
		return "signUp";
	}
	
	@PostMapping("/signUp")
	public String signUp(MemberDTO dto, Model m) {
		int n = 0;
		try {
			n = service.memberAdd(dto);
		} catch (Exception e) {
			
		}
		m.addAttribute("action", "회원관리");
		
		if (n==1) {
			// 성공
			m.addAttribute("message", "회원 등록 성공");
			m.addAttribute("status", "1");
		} else {
			// 실패
			m.addAttribute("message", "회원 등록 실패");
			m.addAttribute("status", "2");
		}

		return "memberResult";
	}
	
	@GetMapping("/login")
	public String login() {
		return "loginForm";
	}

	@PostMapping("/login")
	public String login(@RequestParam Map<String, String> map, Model m, HttpSession session) throws Exception{
		
		MemberDTO dto = service.login(map);
		m.addAttribute("action", "로그인 처리");
		String nextPage = "";
		if (dto == null) {
			// 아이디 및 비번 틀린 경우인 로그인 실패
			m.addAttribute("message", "로그인 실패");
			nextPage = "memberResult";
		} else {
			// 성공
			session.setAttribute("login", dto); // Tomcat 기본 30분
			nextPage = "redirect:/";
		}
		return nextPage;
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session, Model m) {
		
		MemberDTO dto = (MemberDTO)session.getAttribute("login");
		String nextPage = "";
		if (dto != null) {
			session.invalidate();
			nextPage = "redirect:/";
		} else {
			m.addAttribute("message", "요청한 작업은 로그인이 필요한 작업입니다.");
			nextPage = "memberResult";
		}
		return nextPage;
	}

	// 예외처리
	@ExceptionHandler({Exception.class})
	public String error() {
		return "error"; // error.html에서 예외메시지 출력
	}
}
