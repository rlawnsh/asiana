package com.example.mapper;

import java.util.List;


import org.apache.ibatis.annotations.Mapper;

import com.example.dto.BoardDTO;

/*
 *  인터페이스 기반
 *  1. BoardMapper.xml 생성
 *  2. BoardMapper.java (인터페이스)
 *  3. @Mapper 지정
 *  4. namespace값은 반드시 인터페이스의 패키지명.인터페이스명 지정
 *  5. 인터페이스의 메서드명은 mapper의 id값으로 지정
 */

@Mapper
public interface BoardMapper {

	public List<BoardDTO> boardList() throws Exception;
	public int boardWrite(BoardDTO dto) throws Exception;
	public BoardDTO boardByNum(int num) throws Exception;
	public int boardUpdate(BoardDTO dto) throws Exception;
	public int boardDelete(int num) throws Exception;
	public int boardMultiDelete(List<Integer> list) throws Exception;
}
