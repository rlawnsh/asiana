package com.example.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.example.dto.BoardDTO;
import com.example.dto.MemberDTO;


@Mapper
public interface MemberMapper {

	public int memberAdd(MemberDTO dto) throws Exception;
	public MemberDTO login(Map<String, String> map) throws Exception;
}
