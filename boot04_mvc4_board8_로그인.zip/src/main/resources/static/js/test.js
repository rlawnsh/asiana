// 함수: 기능처리담당
function del(num){
	
//	alert(num);
	// 특정사이트 요청
	location.href = "delete?num=" + num;
}
